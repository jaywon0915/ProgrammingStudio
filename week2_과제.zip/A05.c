#include <stdio.h>
int height, weight; // 신장(cm), 체중(kg) 
float bmi; // 비만도 수치 
char bmi_string[5][20] = {"Underweight", "Normal weight", "Overweight", "Mild obesity", "Severe obesity"};
int level;
int bmiLevel(int height, int weight);


int bmiLevel(int height, int weight) {
    bmi = weight / ((height / 100.0) * (height / 100.0));
    if (bmi < 18.5) {
        return 0;
    } else if (bmi < 23) {
        return 1;
    } else if (bmi < 25) {
        return 2;
    } else if (bmi < 30) {
        return 3;
    } else {
        return 4;
    }
}
int main(void) {
    scanf("%d %d", &height, &weight);
    level = bmiLevel(height, weight);
    printf("%s (%d)\n", bmi_string[level], level);
    return 0;
}
