#include <stdio.h>
int height, weight; // 신장(cm), 체중(kg) 
float bmi; // 비만도 수치 
int count = 10;
int overweight;
int order[10];//순서
int k;
int main(void){
for(int i = 0; i < count; i++){
scanf("%d %d", &height, &weight);
bmi = weight / ((height / 100.0) * (height / 100.0));
if(bmi > 25){
    overweight++;
    order[k] = i+1;
    k++;
}

}
for(int j=0; j< overweight; j++){
    printf("%d ", order[j]);
}
printf("\n");
printf("%d\n", overweight);
    return 0;
}