#include <stdio.h>
int height, weight; // 신장(cm), 체중(kg) 
float bmi; // 비만도 수치 
int count, overweight;
int main(void){
scanf("%d", &count);
for(int i = 0; i < count; i++){
scanf("%d %d", &height, &weight);
bmi = weight / ((height / 100.0) * (height / 100.0));
if(bmi > 25){
    overweight++;
}
}
printf("%d\n", overweight);
    return 0;
}