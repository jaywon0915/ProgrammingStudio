#include <stdio.h>
int height, weight; // 신장(cm), 체중(kg) 
float bmi; // 비만도 수치 
int main(void){
scanf("%d %d", &height, &weight);
bmi = weight / ((height / 100.0) * (height / 100.0));
if(bmi > 25){
    printf("%0.1f Overweight\n", bmi);
}
else{
    printf("%0.1f Normal\n", bmi);
}

    return 0;
}